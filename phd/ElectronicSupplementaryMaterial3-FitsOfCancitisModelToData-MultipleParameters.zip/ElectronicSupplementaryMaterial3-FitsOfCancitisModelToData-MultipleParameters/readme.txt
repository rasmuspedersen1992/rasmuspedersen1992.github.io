This zip is a supplementary file for the PhD-thesis of Rasmus Kristoffer Pedersen

Electronic Supplementary Material 4: Model fits of the Cancitis model to data from the DALIAH trial, considering both \hat{d_y0} as well as a_y

Figures as presented and described in section 6.7. 
Figures are as described in "Supplementary Material B: Fits to JAK2V617F data" of the supplementary material for Ottesen et al (2020), see file ElectronicSupplementaryMaterial2-SupplementaryForOttesenEtAl2020.pdf

Filenames described the ID of the patient, and how many data-points were used in the fit. 
Data-points used in the fitting procedure are shown as grey asterisks, while data-points not used are shown as black asterisks.
The relative frequency of malignant mature cells is shown along with the JAK2V617F allele burden. Dotted black line shows untreated disease progression scenario. Full black line displays model-dynamics for the given fitted parameters.
The bottom right panel displays the PK-modelled IFN concentration, based on patient-specific IFN-dosing.
At the top of all figures, an error estimate is shown, defined as the sum of squared errors between the model and the data-points used in the fit, divided by the number of data-points considered. Data-points not used in the fit (shown in black asterisks) do not contribute to the error estimate.