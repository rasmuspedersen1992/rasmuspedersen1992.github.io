This zip is a supplementary file for the PhD-thesis of Rasmus Kristoffer Pedersen

Electronic Supplementary Material 4: Model fits of the Combined Cancitis-Niche model to data from the DALIAH trial

Figures as presented and described in section 11.

Each figure shows patient data for a given patient (Patient-ID in filename). Three figures for each patients are included, for each of the three steps described in the thesis text (Step number in filename). 
The relative frequency of malignant mature cells is shown along with the JAK2V617F allele burden. Dotted black line shows untreated disease progression scenario. Full black line displays model-dynamics for the given fitted parameters, shown in the top-right.
Model-curves in the leukocyte- and thrombocyte panels are scaled, such that the healthy steady state has the value shown above the given panel. 
Example: In P002Step1.png, the sum of mature cells in the model is scaled such that the healthy steady state is 3.59*10^3 for leukocytes and 133*10^3 for thrombocytes. 
The bottom right panel displays the PK-modelled IFN concentration, based on patient-specific IFN-dosing.