This zip is a supplementary file for the PhD-thesis of Rasmus Kristoffer Pedersen

Electronic Supplementary Material 5: Virtual patient simulations, Combined Cancitis-Niche model

Figures as presented and described in section 11.5.

Each figure shows patient data for a given patient (Patient-ID in filename), along with the disease progression curve going through baseline-data, as well as the distribution of 1000 virtual patient simulations with initial conditions in the baseline values. 

The blue dotted curve shows the median response-curve. 
The shaded grey areas displays the distribution, with the darkest grey showing the interval from 25% to 75% of values at the given time-points, the next lightest shows from 10% to 90% while the final interval from 5% to 95% of virtual patient-responses is shown in light grey. 
The bottom right panel displays the IFN concentration used for both the real patient and the virtual patients. 